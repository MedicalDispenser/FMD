#!/bin/sh
echo "kaixo healthcare"
cp -f /tmp/inittab /etc/inittab
cp -f /tmp/passwd /etc/passwd
rm -rf /tmp/inittab
rm -rf /tmp/passwd
ubootenv -s versionFMD=2.0.00019
echo "Corregido error en aviso de error"


