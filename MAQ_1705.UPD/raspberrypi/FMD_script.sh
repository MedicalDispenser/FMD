#!/bin/sh
#===============================================================================
#
#  S.sh
#
#
#  !Revision:    $Revision: 1 $:
#  !Description: 
#
#=============================================================================== 
PATH_FILES="/home/default/raspberrypi"
#Ficheros audios nuevos
#sudo rm -r /home/healthcare/Audio
#sudo rm -r /home/healthcare/Video/SP/*
#sudo mv -f $PATH_FILES/Video/SP/* /home/healthcare/Video/SP/

#sudo chown -R healthcare /home/healthcare/* 

sudo cp $PATH_FILES/splash.png /usr/share/plymouth/themes/pix/splash.png

#Visualizar pantalla de colores al arrancar el sistema
sudo sed -i 's/disable_splash/#disable_splash/g' /boot/config.txt

sudo cp $PATH_FILES/FMD_PIC /home/default/Rescate_PIC

cp $PATH_FILES/FR_012_E.wav /home/healthcare/Audio/FR/
cp $PATH_FILES/PT_012_E.wav /home/healthcare/Audio/PT/
cp $PATH_FILES/SP_012_E.wav /home/healthcare/Audio/SP/
cp $PATH_FILES/UK_012_E.wav /home/healthcare/Audio/UK/
sudo chmod ugo+rw /home/healthcare/Audio/FR/*
sudo chmod ugo+rw /home/healthcare/Audio/PT/*
sudo chmod ugo+rw /home/healthcare/Audio/SP/*
sudo chmod ugo+rw /home/healthcare/Audio/UK/*

rm "/home/healthcare/Video/SP/Cinfa Medicaldispenser Mix.mp4"
rm "/home/healthcare/Video/SP/Cinfa Medicaldispenser Maquina .mp4"
mv "/home/healthcare/Video/SP/Cinfa Medicaldispenser Testimonial.mp4" "/home/healthcare/Video/SP/Servicio Medical Dispenser - Experiencias.mp4"
mv "/home/healthcare/Video/SP/Cinfa Medicaldispenser Captación.mp4" "/home/healthcare/Video/SP/Servicio Medical Dispenser - Presentación.mp4"
mv "/home/healthcare/Video/SP/Instrucciones para la realización de un SPD.mp4" "/home/healthcare/Video/SP/Servicio Medical Dispenser - Funcionamiento.mp4"

# Quitamos servicios no necesarios para ajilizar el arranque del sistema
sudo systemctl disable keyboard-setup.service
sudo systemctl disable dphys-swapfile.service
sudo systemctl disable avahi-daemon.service
sudo systemctl disable sys-kernel-debug.mount?
##//Afecta a los videos
#sudo systemctl disable raspi-config.service 
sudo systemctl start raspi-config.service
sudo systemctl enable raspi-config.service

sudo systemctl disable systemd-udev-trigger.service
# systemctl disable rpi-eeprom-update.service
sudo systemctl disable rsyslog.service
sudo systemctl disable systemd-journald.service
##sudo systemctl disable systemd-fsck-root.service
sudo systemctl disable systemd-logind.service
sudo systemctl disable bluetooth.service
##Aparece texto entre pantallas
#sudo systemctl disable hciuart.service 
sudo systemctl start hciuart.service
sudo systemctl enable hciuart.service

sudo cp $PATH_FILES/pix/* /usr/share/plymouth/themes/pix
sudo plymouth-set-default-theme pix

rm $PATH_FILES/../FMD_script.sh
rm -r $PATH_FILES


echo "FIN actualización 30.68"
#reboot


