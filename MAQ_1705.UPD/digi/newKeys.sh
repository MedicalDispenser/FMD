#!/bin/sh
#===============================================================================
#
#  newKeys.sh
#
#  Copyright (C) 2008 by Digi International Inc.
#  All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify it
#  under the terms of the GNU General Public License version 2 as published by
#  the Free Software Foundation.
#
#
#  !Revision:    $Revision: 1.0 $:
#  !Description: Dropbear ssh create new keys
#
#===============================================================================
rm /etc/dropbear/dropbear_rsa_host_key
rm /etc/dropbear/dropbear_dss_host_key
rm /etc/dropbear/dropbear_ecdsa_host_key

dropbearkey -t rsa -f /etc/dropbear/dropbear_rsa_host_key
dropbearkey -t dss -f /etc/dropbear/dropbear_dss_host_key
dropbearkey -t ecdsa -f /etc/dropbear/dropbear_ecdsa_host_key
