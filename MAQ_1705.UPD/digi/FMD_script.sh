#!/bin/sh
#===============================================================================
#
#  S.sh
#
#
#  !Revision:    $Revision: 1 $:
#  !Description: Actualización de Aplicación 10.56
#
#=============================================================================== 
PATH_FILES="/home/default/digi"
#Nueva versión de dropbear 2019
mv -f $PATH_FILES/passwd /etc
mv -f $PATH_FILES/S60vsftpd.sh /etc/init.d
mv -f $PATH_FILES/S50dropbear.sh /etc/init.d

mv -f $PATH_FILES/dbclient /bin
mv -f $PATH_FILES/dropbearconvert /bin
mv -f $PATH_FILES/dropbearkey /bin
mv -f $PATH_FILES/dropbear /sbin

mv -f $PATH_FILES/S95runapp.sh /etc/init.d
mv -f $PATH_FILES/inittab /etc
mv -f $PATH_FILES/group /etc
mv -f $PATH_FILES/newKeys.sh /etc/dropbear
mv -f $PATH_FILES/PDiagn_*.png /home/default
mv -f $PATH_FILES/CalibrarRaton /home/default

rm /etc/init.d/S80httpd.sh

sh /etc/init.d/S50dropbear.sh restart
sh /etc/init.d/S60vsftpd.sh start

mv -f $PATH_FILES/FMD_PIC /home/default/Rescate_PIC


echo "Bertsio berria definitu"
ubootenv -s versionFMD=10.0.2190
ubootenv -s NSeg=1

rm $PATH_FILES/../FMD_script.sh
#rm -r $PATH_FILES

echo "Actualización de Aplicación 10.58 paquete a liberar mercado" 
#reboot


